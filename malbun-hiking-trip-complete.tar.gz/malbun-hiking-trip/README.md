# Malbun Family Hiking Adventure Website

A beautiful, interactive website for a family hiking trip to Malbun, Liechtenstein, designed to get families excited about their mountain adventure.

## 🌟 Live Demo

Visit the live website: [https://fqhkdxay.manus.space](https://fqhkdxay.manus.space)

## 📋 Project Overview

This website was created for a family hiking trip to Malbun, Liechtenstein from September 19-21, 2025. It features:

- **Interactive Design**: Tabbed navigation with detailed information about hiking trails, accommodation, weather, and activities
- **Family-Focused Content**: Specially curated trails suitable for children aged 2-6 years
- **Beautiful Visuals**: Stunning landscape photography and engaging animations
- **Responsive Layout**: Works perfectly on desktop, tablet, and mobile devices

## 🏔️ Featured Content

### Hiking Trails
- **Swing Trail (Schaukelpfad)**: 10 spectacular swings with panoramic views
- **Explorer Path (Forscherweg)**: Interactive research stations for young children
- **Alpine Heart Trail (Alpherz)**: Educational stations about alpine culture

### Accommodation
- **JUFA Hotel Malbun**: 4-star family-friendly hotel with detailed amenities and contact information

### Practical Information
- September weather forecast and packing recommendations
- Additional family activities (llama trekking, alpine minigolf, adventure rooms)
- Safety guidelines and transportation information

## 🛠️ Technology Stack

- **React 18**: Modern React with hooks and functional components
- **Vite**: Fast build tool and development server
- **Tailwind CSS**: Utility-first CSS framework for styling
- **shadcn/ui**: High-quality UI components
- **Lucide React**: Beautiful icon library
- **Framer Motion**: Smooth animations and transitions

## 🚀 Getting Started

### Prerequisites
- Node.js (version 18 or higher)
- pnpm (preferred) or npm

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd malbun-hiking-trip
```

2. Install dependencies:
```bash
pnpm install
# or
npm install
```

3. Start the development server:
```bash
pnpm run dev
# or
npm run dev
```

4. Open your browser and visit `http://localhost:5173`

### Building for Production

```bash
pnpm run build
# or
npm run build
```

The built files will be in the `dist` directory.

## 📁 Project Structure

```
malbun-hiking-trip/
├── public/                 # Static assets
├── src/
│   ├── assets/
│   │   └── images/        # All hiking and hotel images
│   ├── components/
│   │   └── ui/           # shadcn/ui components
│   ├── App.jsx           # Main application component
│   ├── App.css           # Global styles and Tailwind config
│   ├── main.jsx          # Application entry point
│   └── index.css         # Base styles
├── index.html            # HTML template
├── package.json          # Dependencies and scripts
├── tailwind.config.js    # Tailwind configuration
└── vite.config.js        # Vite configuration
```

## 🎨 Design Features

- **Hero Section**: Rotating landscape images with fade transitions
- **Interactive Tabs**: Smooth navigation between different content sections
- **Card Layouts**: Clean, organized presentation of information
- **Responsive Design**: Mobile-first approach with breakpoints for all screen sizes
- **Animations**: Subtle fade-in effects and hover states
- **Color Scheme**: Mountain-inspired greens and blues with professional typography

## 📸 Image Assets

All images are included in the `src/assets/images/` directory:
- Malbun landscape photos
- JUFA Hotel exterior and interior shots
- Hiking trail images (swing trail, explorer path, alpine heart trail)
- Family activity photos

## 🌐 Deployment

The website is deployed and can be easily redeployed to various platforms:
- **Current deployment**: Manus hosting platform
- **Compatible with**: Vercel, Netlify, GitHub Pages, and other static hosting services

## 📝 Content Management

All content is managed within the React components. To update:
- **Trail information**: Edit the `trails` array in `App.jsx`
- **Hotel details**: Modify the hotel section content
- **Weather data**: Update the `weatherInfo` object
- **Images**: Replace files in `src/assets/images/` and update import statements

## 🤝 Contributing

This project was created for a specific family trip, but feel free to fork and adapt it for your own adventures!

## 📄 License

This project is open source and available under the MIT License.

---

**Created with ❤️ for an amazing family hiking adventure in the beautiful mountains of Liechtenstein!**

