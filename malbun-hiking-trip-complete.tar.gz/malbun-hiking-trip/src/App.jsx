import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Calendar, MapPin, Users, Clock, Star, Mountain, Heart, Camera, Thermometer, CloudRain, Sun } from 'lucide-react'
import './App.css'

// Import images
import malbunLandscape1 from './assets/images/malbun_landscape_1.jpg'
import malbunLandscape2 from './assets/images/malbun_landscape_2.jpg'
import malbunLandscape3 from './assets/images/malbun_landscape_3.jpg'
import jufahotelExterior from './assets/images/jufa_hotel_exterior.jpg'
import jufahotelInterior from './assets/images/jufa_hotel_interior.webp'
import jufahotelRoom from './assets/images/jufa_hotel_room.webp'
import swingTrail1 from './assets/images/swing_trail_1.jpg'
import swingTrail2 from './assets/images/swing_trail_2.jpg'
import explorerPath1 from './assets/images/explorer_path_1.jpg'
import alpherzTrail1 from './assets/images/alpherz_trail_1.jpg'
import familyHiking1 from './assets/images/family_hiking_1.jpg'
import familyHiking2 from './assets/images/family_hiking_2.jpg'
import childrenActivities from './assets/images/children_activities.jpg'

function App() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isVisible, setIsVisible] = useState(false)

  const heroImages = [malbunLandscape1, malbunLandscape2, malbunLandscape3]

  useEffect(() => {
    setIsVisible(true)
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % heroImages.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const trails = [
    {
      name: "Swing Trail (Schaukelpfad)",
      duration: "2 hours",
      distance: "5.5 km",
      difficulty: "Easy",
      ageGroup: "Perfect for all ages",
      highlights: "10 spectacular swings with panoramic views",
      image: swingTrail1,
      description: "A playful circular trail featuring ten amazing open-air swings positioned at the most scenic viewpoints. Kids will love swinging while taking in breathtaking mountain vistas!"
    },
    {
      name: "Explorer Path (Forscherweg)",
      duration: "2 hours",
      distance: "4.4 km",
      difficulty: "Easy",
      ageGroup: "Ideal for ages 2-6",
      highlights: "10 interactive research stations",
      image: explorerPath1,
      description: "Specially designed for young explorers! Features hands-on activities, a 'Musical Egg' stone, playground, and educational stations. Equipment rental available for the full experience."
    },
    {
      name: "Alpine Heart Trail (Alpherz)",
      duration: "2 hours",
      distance: "5.5 km",
      difficulty: "Easy-Moderate",
      ageGroup: "Family-friendly",
      highlights: "7 interactive alpine culture stations",
      image: alpherzTrail1,
      description: "Learn about alpine culture through interactive stations covering farming, wildlife, and local history. Collect stamps at each station for a reward at the end!"
    }
  ]

  const weatherInfo = {
    temperature: { high: 60, low: 42, unit: "°F" },
    conditions: "Moderately chilly, humid but cool",
    rainChance: 49,
    clothing: "Sweater recommended, bring umbrella"
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50">
      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden">
        <div className="absolute inset-0">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentImageIndex ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={image}
                alt={`Malbun landscape ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className={`relative z-10 flex items-center justify-center h-full text-white text-center px-4 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="max-w-4xl">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
              Malbun Family Adventure
            </h1>
            <p className="text-xl md:text-2xl mb-8 animate-fade-in-delay">
              Join us for an unforgettable hiking trip in the heart of Liechtenstein
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Calendar className="w-5 h-5 mr-2" />
                September 19-21, 2025
              </Badge>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <MapPin className="w-5 h-5 mr-2" />
                Malbun, Liechtenstein
              </Badge>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Users className="w-5 h-5 mr-2" />
                Family-Friendly
              </Badge>
            </div>
            <Button size="lg" className="text-lg px-8 py-4 animate-bounce">
              Explore Our Adventure
            </Button>
          </div>
        </div>
      </section>

      {/* Trip Overview */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-gray-800">
            Our Mountain Adventure Awaits
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Mountain className="w-12 h-12 mx-auto text-green-600 mb-4" />
                <CardTitle>Perfect for Families</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Specially selected trails suitable for children aged 2-6 years with interactive elements and safe, easy paths.</p>
              </CardContent>
            </Card>
            
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Heart className="w-12 h-12 mx-auto text-red-500 mb-4" />
                <CardTitle>Memorable Experiences</CardTitle>
              </CardHeader>
              <CardContent>
                <p>From mountain swings to explorer trails, every moment is designed to create lasting family memories.</p>
              </CardContent>
            </Card>
            
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Star className="w-12 h-12 mx-auto text-yellow-500 mb-4" />
                <CardTitle>Comfort & Quality</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Stay at the 4-star JUFA Hotel Malbun with family-friendly amenities and direct access to hiking trails.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Main Content Tabs */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <Tabs defaultValue="trails" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="trails">Hiking Trails</TabsTrigger>
              <TabsTrigger value="hotel">Our Hotel</TabsTrigger>
              <TabsTrigger value="weather">Weather Info</TabsTrigger>
              <TabsTrigger value="activities">Activities</TabsTrigger>
            </TabsList>
            
            <TabsContent value="trails" className="mt-8">
              <h3 className="text-3xl font-bold mb-8 text-center">Family-Friendly Hiking Trails</h3>
              <div className="grid gap-8">
                {trails.map((trail, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
                    <div className="md:flex">
                      <div className="md:w-1/3">
                        <img
                          src={trail.image}
                          alt={trail.name}
                          className="w-full h-64 md:h-full object-cover"
                        />
                      </div>
                      <div className="md:w-2/3 p-6">
                        <CardHeader className="p-0 mb-4">
                          <CardTitle className="text-2xl text-green-700">{trail.name}</CardTitle>
                          <CardDescription className="text-lg">{trail.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="p-0">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                            <div className="flex items-center">
                              <Clock className="w-4 h-4 mr-2 text-blue-600" />
                              <span className="text-sm">{trail.duration}</span>
                            </div>
                            <div className="flex items-center">
                              <MapPin className="w-4 h-4 mr-2 text-red-600" />
                              <span className="text-sm">{trail.distance}</span>
                            </div>
                            <div className="flex items-center">
                              <Mountain className="w-4 h-4 mr-2 text-green-600" />
                              <span className="text-sm">{trail.difficulty}</span>
                            </div>
                            <div className="flex items-center">
                              <Users className="w-4 h-4 mr-2 text-purple-600" />
                              <span className="text-sm">{trail.ageGroup}</span>
                            </div>
                          </div>
                          <Badge variant="outline" className="mb-2">
                            {trail.highlights}
                          </Badge>
                        </CardContent>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="hotel" className="mt-8">
              <h3 className="text-3xl font-bold mb-8 text-center">JUFA Hotel Malbun ⭐⭐⭐⭐</h3>
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div>
                  <img
                    src={jufahotelExterior}
                    alt="JUFA Hotel Malbun exterior"
                    className="w-full h-64 object-cover rounded-lg shadow-lg"
                  />
                </div>
                <div>
                  <h4 className="text-2xl font-semibold mb-4 text-green-700">Perfect for Families</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• 58 modern rooms with family configurations</li>
                    <li>• Indoor and outdoor playgrounds</li>
                    <li>• Wellness area with sauna</li>
                    <li>• Restaurant with regional cuisine</li>
                    <li>• Free parking and Wi-Fi</li>
                    <li>• Direct access to hiking trails</li>
                    <li>• Equipment storage for hiking gear</li>
                  </ul>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Hotel Amenities</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <img src={jufahotelInterior} alt="Hotel interior" className="rounded-lg" />
                      <img src={jufahotelRoom} alt="Hotel room" className="rounded-lg" />
                    </div>
                    <p className="mt-4 text-gray-600">
                      Modern alpine comfort with family-friendly facilities and stunning mountain views.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p><strong>Address:</strong> Malbunstraße 60, 9497 Malbun, Liechtenstein</p>
                      <p><strong>Phone:</strong> +423 399 2000</p>
                      <p><strong>Email:</strong> malbun@jufahotels.com</p>
                      <p><strong>Rating:</strong> 4.5/5 stars (1,582+ reviews)</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="weather" className="mt-8">
              <h3 className="text-3xl font-bold mb-8 text-center">September Weather in Malbun</h3>
              <div className="grid md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Thermometer className="w-6 h-6 mr-2 text-orange-500" />
                      Temperature
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-blue-600 mb-2">
                        {weatherInfo.temperature.high}°F / {weatherInfo.temperature.low}°F
                      </div>
                      <p className="text-gray-600">{weatherInfo.conditions}</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CloudRain className="w-6 h-6 mr-2 text-blue-500" />
                      Weather Conditions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Chance of Rain:</span>
                        <span className="font-semibold">{weatherInfo.rainChance}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Daylight Hours:</span>
                        <span className="font-semibold">12.6 hours</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Humidity:</span>
                        <span className="font-semibold">92%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card className="mt-8">
                <CardHeader>
                  <CardTitle>What to Pack</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h5 className="font-semibold mb-3 text-green-700">Essential Clothing</h5>
                      <ul className="space-y-1 text-gray-700">
                        <li>• Warm layers (sweaters, fleece)</li>
                        <li>• Waterproof jackets and rain gear</li>
                        <li>• Comfortable hiking boots</li>
                        <li>• Warm clothes for children</li>
                        <li>• Extra socks and underwear</li>
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-semibold mb-3 text-blue-700">Hiking Essentials</h5>
                      <ul className="space-y-1 text-gray-700">
                        <li>• Backpack for day hikes</li>
                        <li>• Water bottles and snacks</li>
                        <li>• First aid kit</li>
                        <li>• Camera for memories</li>
                        <li>• Sun protection (hat, sunglasses)</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="activities" className="mt-8">
              <h3 className="text-3xl font-bold mb-8 text-center">Additional Family Activities</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">Llama & Alpaca Trekking</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <img src={familyHiking1} alt="Family hiking" className="w-full h-32 object-cover rounded mb-3" />
                    <p className="text-sm text-gray-600">Gentle animals perfect for young children to interact with and learn about alpine farming.</p>
                  </CardContent>
                </Card>
                
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">Alpine Minigolf</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <img src={familyHiking2} alt="Family activities" className="w-full h-32 object-cover rounded mb-3" />
                    <p className="text-sm text-gray-600">Fun family activity located in Malbun village, perfect for relaxing after hiking.</p>
                  </CardContent>
                </Card>
                
                <Card className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">Outdoor Adventure Rooms</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <img src={childrenActivities} alt="Children activities" className="w-full h-32 object-cover rounded mb-3" />
                    <p className="text-sm text-gray-600">iPad-based outdoor escape room experience requiring teamwork and problem-solving.</p>
                  </CardContent>
                </Card>
              </div>
              
              <Card className="mt-8">
                <CardHeader>
                  <CardTitle>Safety & Practical Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h5 className="font-semibold mb-3 text-red-600">Safety Guidelines</h5>
                      <ul className="space-y-1 text-gray-700">
                        <li>• Always supervise children on trails</li>
                        <li>• Stay on marked paths</li>
                        <li>• Carry emergency contact information</li>
                        <li>• Check weather conditions before hiking</li>
                        <li>• Inform hotel staff of your hiking plans</li>
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-semibold mb-3 text-green-600">Getting Around</h5>
                      <ul className="space-y-1 text-gray-700">
                        <li>• Hotel is walking distance to trailheads</li>
                        <li>• LIEmobil bus line 21 to "Malbun, Jöraboda"</li>
                        <li>• Parking at Parkhaus Malbun available</li>
                        <li>• 30 minutes drive from Vaduz</li>
                        <li>• Equipment rental available at tourist center</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready for Our Mountain Adventure?</h2>
          <p className="text-xl mb-8">
            Join us for an unforgettable family hiking experience in the beautiful mountains of Liechtenstein. 
            Perfect trails for children, comfortable accommodation, and memories that will last a lifetime!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
              <Calendar className="w-5 h-5 mr-2" />
              Book Your Spot
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-4 text-white border-white hover:bg-white hover:text-green-600">
              <Camera className="w-5 h-5 mr-2" />
              View Photo Gallery
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 bg-gray-800 text-white">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-lg mb-4">Malbun Family Hiking Adventure • September 19-21, 2025</p>
          <p className="text-gray-400">
            Created with ❤️ for our amazing families. Get ready for an incredible mountain adventure!
          </p>
        </div>
      </footer>
    </div>
  )
}

export default App

